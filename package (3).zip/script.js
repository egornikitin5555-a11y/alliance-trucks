// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initSmoothScrolling();
    initModal();
    initFormHandlers();
    initScrollEffects();
});

// Smooth scrolling for anchor links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Modal functionality
function initModal() {
    const modal = document.getElementById('modal');
    const modalContent = document.getElementById('modal-content');
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal();
        }
    });
    
    // Close modal with escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeModal();
        }
    });
}

// Show modal with specific form
function showForm(formType) {
    const modal = document.getElementById('modal');
    const modalForm = document.getElementById('modal-form');
    
    const forms = {
        'call': `
            <h2>Заказать звонок</h2>
            <form id="callForm" onsubmit="submitForm(event, 'call')">
                <div class="form-group">
                    <label for="callName">Имя *</label>
                    <input type="text" id="callName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="callPhone">Телефон *</label>
                    <input type="tel" id="callPhone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="callMessage">Комментарий</label>
                    <textarea id="callMessage" name="message" placeholder="Кратко опишите вашу мебель..."></textarea>
                </div>
                <button type="submit" class="btn-primary">Заказать звонок</button>
            </form>
        `,
        'dry-cleaning': `
            <h2>Узнать стоимость химчистки</h2>
            <form id="dryCleanForm" onsubmit="submitForm(event, 'dry-cleaning')">
                <div class="form-group">
                    <label for="dcName">Имя *</label>
                    <input type="text" id="dcName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="dcPhone">Телефон *</label>
                    <input type="tel" id="dcPhone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="dcService">Услуга *</label>
                    <select id="dcService" name="service" required>
                        <option value="">Выберите услугу</option>
                        <option value="sofa">Химчистка дивана</option>
                        <option value="mattress">Химчистка матраса</option>
                        <option value="armchair">Химчистка кресла</option>
                        <option value="chair">Химчистка стула</option>
                        <option value="carpet">Чистка ковра</option>
                        <option value="other">Другое</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="dcDetails">Описание мебели</label>
                    <textarea id="dcDetails" name="details" placeholder="Размер, материал, степень загрязнения..."></textarea>
                </div>
                <button type="submit" class="btn-primary">Получить расчет</button>
            </form>
        `,
        'consultation': `
            <h2>Бесплатная консультация</h2>
            <form id="consultForm" onsubmit="submitForm(event, 'consultation')">
                <div class="form-group">
                    <label for="consName">Имя *</label>
                    <input type="text" id="consName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="consPhone">Телефон *</label>
                    <input type="tel" id="consPhone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="consEmail">Email</label>
                    <input type="email" id="consEmail" name="email">
                </div>
                <div class="form-group">
                    <label for="consQuestion">Ваш вопрос</label>
                    <textarea id="consQuestion" name="question" placeholder="Задайте вопрос специалисту..."></textarea>
                </div>
                <button type="submit" class="btn-primary">Задать вопрос</button>
            </form>
        `
    };
    
    modalForm.innerHTML = forms[formType] || forms['consultation'];
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Close modal
function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Form submission handlers
function initFormHandlers() {
    // Phone number formatting
    document.addEventListener('input', function(e) {
        if (e.target.type === 'tel') {
            formatPhone(e.target);
        }
    });
    
    // Form validation
    document.addEventListener('submit', function(e) {
        if (e.target.matches('form')) {
            e.preventDefault();
            validateForm(e.target);
        }
    });
}

// Phone number formatting
function formatPhone(input) {
    let value = input.value.replace(/\D/g, '');
    if (value.startsWith('7')) {
        value = value.substring(1);
    }
    if (value.startsWith('8')) {
        value = value.substring(1);
    }
    
    if (value.length >= 10) {
        value = value.substring(0, 10);
        value = value.replace(/(\d{3})(\d{3})(\d{2})(\d{2})/, '+7 ($1) $2-$3-$4');
    } else if (value.length >= 7) {
        value = value.replace(/(\d{3})(\d{3})/, '($1) $2-');
    } else if (value.length >= 4) {
        value = value.replace(/(\d{3})/, '($1) ');
    }
    
    input.value = value;
}

// Form validation
function validateForm(form) {
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'Это поле обязательно для заполнения');
            isValid = false;
        } else {
            clearFieldError(field);
        }
        
        // Phone validation
        if (field.type === 'tel') {
            const phoneRegex = /^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$/;
            if (!phoneRegex.test(field.value)) {
                showFieldError(field, 'Введите корректный номер телефона');
                isValid = false;
            }
        }
        
        // Email validation
        if (field.type === 'email' && field.value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(field.value)) {
                showFieldError(field, 'Введите корректный email адрес');
                isValid = false;
            }
        }
    });
    
    if (isValid) {
        submitForm(form);
    }
}

// Show field error
function showFieldError(field, message) {
    clearFieldError(field);
    field.style.borderColor = '#e74c3c';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.style.color = '#e74c3c';
    errorDiv.style.fontSize = '0.9rem';
    errorDiv.style.marginTop = '0.5rem';
    errorDiv.textContent = message;
    
    field.parentNode.appendChild(errorDiv);
}

// Clear field error
function clearFieldError(field) {
    field.style.borderColor = '#ecf0f1';
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

// Form submission
function submitForm(event, formType = null) {
    if (event) {
        event.preventDefault();
    }
    
    const form = event ? event.target : document.querySelector('form');
    const submitButton = form.querySelector('button[type="submit"]');
    
    // Show loading state
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Отправка...';
    submitButton.disabled = true;
    submitButton.classList.add('loading');
    
    // Collect form data
    const formData = new FormData(form);
    const data = {};
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    // Add form type
    data.formType = formType || form.id;
    data.timestamp = new Date().toISOString();
    
    // Simulate form submission (replace with actual submission logic)
    setTimeout(() => {
        console.log('Form submitted:', data);
        
        // Show success message
        showSuccessMessage();
        
        // Reset form
        form.reset();
        
        // Close modal after delay
        setTimeout(() => {
            closeModal();
        }, 2000);
        
        // Reset button
        submitButton.textContent = originalText;
        submitButton.disabled = false;
        submitButton.classList.remove('loading');
    }, 1500);
}

// Show success message
function showSuccessMessage() {
    const message = document.createElement('div');
    message.className = 'success-message';
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #27ae60;
        color: white;
        padding: 1rem 2rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 3000;
        animation: slideInRight 0.3s ease-out;
    `;
    message.innerHTML = `
        <strong>Спасибо!</strong><br>
        Мы свяжемся с вами в ближайшее время.
    `;
    
    document.body.appendChild(message);
    
    // Remove message after 5 seconds
    setTimeout(() => {
        message.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            message.remove();
        }, 300);
    }, 5000);
}

// Scroll effects
function initScrollEffects() {
    // Header background on scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.backgroundColor = '#ffffff';
            header.style.backdropFilter = 'none';
        }
    });
    
    // Parallax effect for hero image
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const heroImage = document.querySelector('.hero-image');
        if (heroImage) {
            const speed = 0.3;
            heroImage.style.transform = `translateY(${scrolled * speed}px)`;
        }
    });
    
    // Fade in animation for sections
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe sections for animation
    document.querySelectorAll('section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
}

// Scroll to section
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Analytics tracking (placeholder)
function trackEvent(eventName, eventData) {
    // Google Analytics 4 event tracking
    if (typeof gtag !== 'undefined') {
        gtag('event', eventName, eventData);
    }
    
    // Console log for development
    console.log('Event tracked:', eventName, eventData);
}

// Track form submissions
document.addEventListener('submit', function(e) {
    if (e.target.matches('form')) {
        trackEvent('form_submit', {
            form_type: e.target.id,
            page_title: document.title
        });
    }
});

// Track button clicks
document.addEventListener('click', function(e) {
    if (e.target.matches('.btn-primary, .btn-secondary')) {
        trackEvent('button_click', {
            button_text: e.target.textContent.trim(),
            page_title: document.title
        });
    }
});

// Add loading states for images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('load', function() {
            this.style.opacity = '1';
        });
        img.addEventListener('error', function() {
            this.style.opacity = '0.5';
            this.alt = 'Изображение не загружено';
        });
        img.style.opacity = '0';
        img.style.transition = 'opacity 0.3s ease';
    });
});

// Mobile menu toggle (if needed)
function initMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav');
    
    if (menuToggle && nav) {
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // You can send errors to your analytics service here
});

// Performance monitoring
window.addEventListener('load', function() {
    const loadTime = performance.now();
    console.log('Page load time:', Math.round(loadTime), 'ms');
    
    // Track page load time
    trackEvent('page_load_time', {
        load_time: Math.round(loadTime),
        page_title: document.title
    });
});

// Service Worker registration (for PWA features)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}